import test from "node:test";
import assert from "node:assert/strict";
import {
  ACHIEVEMENTS,
  CORE_QUESTS,
  SAVE_VERSION,
  addDays,
  applyXp,
  createSave,
  customStudyXp,
  dayStatus,
  evaluateAchievements,
  getCurrentStreak,
  getStats,
  isDayComplete,
  localDate,
  migrateLegacySave,
  normalizeSave,
  rankForLevel,
  updateBestStreak,
  xpRequired,
  xpToLevel
} from "../src/domain.js";
import { exportSave, parseImportedSave } from "../src/storage.js";

function completeDay(save, date) {
  const day = save.history[date] ||= {
    date,
    quests: Object.fromEntries(CORE_QUESTS.map(quest => [quest.id, true])),
    studyMinutes: 1,
    studyEntries: [],
    xpDelta: 0,
    cheatAttempts: [],
    customQuests: []
  };
  day.quests = Object.fromEntries(CORE_QUESTS.map(quest => [quest.id, true]));
  day.studyMinutes = 1;
  return day;
}

test("level thresholds and rank bands match the system specification", () => {
  assert.deepEqual([1, 2, 3, 4, 5].map(xpRequired), [500, 750, 1000, 1250, 1500]);
  assert.deepEqual(xpToLevel(499), { level: 1, xpIntoLevel: 499 });
  assert.deepEqual(xpToLevel(500), { level: 2, xpIntoLevel: 0 });
  assert.deepEqual(xpToLevel(1250), { level: 3, xpIntoLevel: 0 });
  assert.deepEqual([1, 5, 10, 20, 40, 75, 150, 300, 999].map(rankForLevel), ["E", "D", "C", "B", "A", "S", "SS", "SSS", "X"]);
});

test("study XP is proportional to cumulative daily time, including tiny sessions", () => {
  assert.equal(customStudyXp(0, 30), 25);
  assert.equal(customStudyXp(30, 31), 0);
  assert.equal(customStudyXp(31, 60), 25);
  assert.equal(customStudyXp(0, 480), 400);
});

test("XP penalties update level progress and preserve the signed lifetime total", () => {
  const save = createSave();
  const change = applyXp(save, -5000);
  assert.equal(save.player.totalXp, -5000);
  assert.equal(save.player.level, 1);
  assert.equal(save.player.xpIntoLevel, 0);
  assert.equal(change.after.rank, "E");
  assert.equal(save.history[localDate()].xpDelta, -5000);
});

test("daily completion and streaks use contiguous completed history", () => {
  const save = createSave("2026-10-01");
  const dates = ["2026-10-01", "2026-10-02", "2026-10-03"];
  dates.forEach(date => completeDay(save, date));
  assert.equal(isDayComplete(save.history[dates[0]]), true);
  assert.equal(getCurrentStreak(save, dates[2]), 3);
  updateBestStreak(save);
  assert.equal(getStats(save, dates[2]).bestStreak, 3);
  assert.equal(getCurrentStreak(save, "2026-10-05"), 0);
  assert.equal(addDays("2026-10-03", 1), "2026-10-04");
});

test("a study-only day does not complete the core daily objective set", () => {
  const save = createSave("2026-10-05");
  save.history["2026-10-05"].studyMinutes = 60;
  assert.equal(isDayComplete(save.history["2026-10-05"]), false);
});

test("calendar marks a recorded violation as partial activity without counting it as progress", () => {
  const save = createSave("2026-10-05");
  save.history["2026-10-05"].cheatAttempts.push({ reason: "DAILY STUDY CAP EXCEEDED", penaltyApplied: true });
  assert.equal(dayStatus(save.history["2026-10-05"]), "PARTIAL");
  assert.equal(getStats(save, "2026-10-05").activeDays, 0);
});

test("export preserves the complete versioned history snapshot", () => {
  const save = createSave("2026-10-05");
  save.history["2026-10-04"] = { ...save.history["2026-10-05"], date: "2026-10-04", studyMinutes: 40 };
  const exported = JSON.parse(exportSave(save));
  assert.equal(exported.version, SAVE_VERSION);
  assert.equal(exported.history["2026-10-04"].studyMinutes, 40);
  assert.ok(exported.history["2026-10-05"]);
});

test("all configured achievements unlock once when their real milestones are met", () => {
  const today = "2026-10-05";
  const save = createSave(today);
  const dates = Array.from({ length: 7 }, (_, index) => addDays(today, index - 6));
  dates.forEach(date => completeDay(save, date));
  save.history[dates[0]].studyMinutes = 300;
  save.history[dates[1]].studyMinutes = 300;
  applyXp(save, 3500);
  updateBestStreak(save);

  const unlocked = evaluateAchievements(save);
  assert.deepEqual(unlocked.map(item => item.id).sort(), ACHIEVEMENTS.map(item => item.id).sort());
  assert.ok(Object.values(save.achievements).every(date => date === today));
  assert.deepEqual(evaluateAchievements(save), []);
});

test("legacy saves migrate into the V10 dated history without discarding current progress", () => {
  const legacy = {
    level: 2,
    xp: 125,
    streak: 2,
    today: { date: "2026-10-04", quests: { nj: true, exercise: false, wake: false, junk: false }, studyMinutes: 45, xp: 137, cheat: false, customTasks: [{ id: 12, name: "Read Biology", xp: 80, completed: true }] }
  };
  const save = migrateLegacySave(legacy, "2026-10-05");
  assert.equal(save.version, SAVE_VERSION);
  assert.equal(save.player.totalXp, 625);
  assert.equal(save.history["2026-10-04"].studyMinutes, 45);
  assert.equal(save.history["2026-10-04"].quests.nj, true);
  assert.equal(save.history["2026-10-04"].customQuests[0].completed, true);
  assert.ok(save.history["2026-10-05"]);
});

test("import validation rejects malformed files and keeps today's anti-cheat lock", () => {
  assert.throws(() => normalizeSave({ unexpected: true }), /not a valid ARISE/);
  const today = localDate();
  const current = createSave(today);
  current.history[today].cheatAttempts.push({ reason: "DAILY STUDY CAP EXCEEDED", attemptedTotalMinutes: 500, penaltyApplied: true });
  applyXp(current, -5000);
  const imported = parseImportedSave(JSON.stringify(createSave(today)), current);
  assert.equal(imported.history[today].cheatAttempts.length, 1);
  assert.equal(imported.player.totalXp, -5000);
  assert.equal(imported.history[today].xpDelta, -5000);
});
